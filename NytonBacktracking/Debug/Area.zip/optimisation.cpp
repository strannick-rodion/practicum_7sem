#include <iostream>
#include <cmath>
#include <vector>
#include "optimisation.h"
#include <algorithm>
#include "Area.h"

using namespace std;

int function2::getK()
{ return  2; }

double function2:: getf(vector<double> x)
{
    return (x[1] - 3) * (x[1] - 3) + (x[0] + 5) * (x[0] + 5) - 3;
}

int function3::getK()
{ return  3; }

double function3:: getf(vector<double> x)
{
    return x[1] * x[1] + x[2] * x[2] + x[0] * x[0] + 5;
}




vector<vector<double>> Derivaties::getHessian()
{
    return hessian;
}
vector<double> Derivaties::getGradient()
{
    return gradient;
}

int Derivaties::getN()
{
    return n;
}
void Derivaties::calcGradient(Function& f, vector<double>& x)
{
    double rtemp, ltemp;
    if (!gradient.empty())
    {
        gradient.clear();
    }
    for (int i = 0; i < n; ++i)
    {
        x[i] -= eps;
        ltemp = f.getf(x);
        x[i] += 2 * eps;
        rtemp = f.getf(x);
        gradient.push_back((rtemp - ltemp) / (2 * eps));
        x[i] -= eps;

    }
}
void Derivaties::calcHessian(Function& f, vector<double>x)
{
    double ftemp1, ftemp2, ftemp3;
    if (!hessian.empty())
    {
        hessian.clear();
    }
    vector<double> vectemp(n, 0);
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            x[i] += eps;
            ftemp1 = f.getf(x);
            x[j] += eps;
            ftemp3 = f.getf(x);
            x[i] -= eps;
            ftemp2 = f.getf(x);
            x[j] -= eps;
            vectemp[j] = (ftemp3 - ftemp2 - ftemp1 + f.getf(x)) / (eps * eps);
        }
        hessian.push_back(vectemp);
    }
    cout << "hessian:" << endl << hessian[0][0] << " " << hessian[0][1] << endl << hessian[1][0] << " " << hessian[1][1] << endl << "__" << endl;

}

void gauseforward(vector<vector<double>>& b, vector<vector<double>>& a, int n, int k)
{
    int j, i;
    double temp = a[k][k];
    for (i = 0; (i < n) && (a[k][k] != 0); ++i)
    {

        //  cout << "akk=" << a[k][k] << endl;
        b[k][i] = b[k][i] / temp;
        // cout << "bki=" << b[k][i]<< endl;
        a[k][i] = a[k][i] / temp;
        // cout << "aki=" << a[k][i] << endl;
    }
    for (i = k + 1; i < n; i++) {
        double cur = a[i][k];
        for (j = 0; j < n; j++)
        {
            b[i][j] = b[i][j] - cur * b[k][j];
            a[i][j] = a[i][j] - cur * a[k][j];
        }
    }
    //  cout << "I`m in forward" << endl;
     // cout << "forwardInv:" << endl << b[0][0] << " " << b[0][1] << endl << b[1][0] << " " << b[1][1] << endl << "__" << endl;
     // cout << "forwardA:" << endl << a[0][0] << " " << a[0][1] << endl << a[1][0] << " " << a[1][1] << endl << "__" << endl;
}


void gauseback(vector<vector<double>>& b, vector<vector<double>>& a, int n, int k)
{
    int j, i;
    double temp = a[k][k];
    for (i = n - 1; (i >= 0) && (a[k][k] != 0); --i)
    {
        b[k][i] = b[k][i] / temp;
        a[k][i] = a[k][i] / temp;
    }
    for (i = k - 1; i >= 0; i--)
    {
        double cur = a[i][k];
        for (j = n - 1; j >= 0; j--)
        {
            b[i][j] = b[i][j] - cur * b[k][j];
            a[i][j] = a[i][j] - cur * a[k][j];
        }
    }
    // cout << "backInv:" << endl << b[0][0] << " " << b[0][1] << endl << b[1][0] << " " << b[1][1] << endl << "__" << endl;
    // cout << "backA:" << endl << a[0][0] << " " << a[0][1] << endl << a[1][0] << " " << a[1][1] << endl << "__" << endl;
}

void inverse(const vector<vector<double>>& a, vector<vector<double>>& b, int n)
{
    vector<vector<double>> temp(a);
    // cout << "Ain:" << endl << a[0][0] << " " << a[0][1] << endl << a[1][0] << " " << a[1][1] << endl << "__" << endl;
    for (int i = 0; i < n; ++i)
    {
        gauseforward(b, temp, n, i);
       cout << "After:" << endl << b[0][0] << " " << b[0][1] << endl << b[1][0] << " " << b[1][1] << endl << "__" << endl;
    }

    for (int i = n - 1; i >= 0; --i)
        gauseback(b, temp, n, i);

}



    int optimisation::getIter() 
    { 
        return iter; 
      }

    vector<double> optimisation::getRez()
    {
        return vecX.back();
    }



    double Newton::getEps() { return eps; }
    int Newton::getIter() { return iter; }

    void  Newton:: matByRow(vector<vector<double>>& mat, const vector<double>& vec, vector<double>& p, int n)
    {
        double sum = 0;
        for (int i = 0; i < n; ++i)
        {
            sum = 0;
            for (int j = 0; j < n; ++j)
            {
                sum += mat[i][j] * vec[j];
            }
            p.push_back(-sum);
        }
    }
    vector<double> Newton::calcP(Derivaties* d)
    {
  
        int n = d->getN();
        vector<double> temp(n, 0);
        for (int j = 0; j < n; ++j)
        {
            invMatr.push_back(temp);
            invMatr[j][j] = 1;
        }

        inverse(d->getHessian(), invMatr, n);
        
        matByRow(invMatr, d->getGradient(), p, n);

        invMatr.clear();
        return p;
    }

    double  Newton::getNorma( const vector<double>& x, int n)
    {
        double norm = 0;
        for (int i = 0; i < n; ++i)
        {
            norm += x[i] * x[i];
        }
        norm = sqrt(norm);
        return norm;
    }

    double Newton::getNorma(double x) 
    {
        return abs(x);
    }

    bool Newton:: Stop( Function& f, Derivaties* d, int ind)
    {
        int size = d->getN();
        if (getNorma(d->getGradient(), size) < eps)
            return false;
        if (ind > 0)
        {
            for (int i = 0; i < size; ++i)
            {
                temp[i] = vecX[ind][i] - vecX[ind-1][i];
                cout << "temp[" << i << "]=" << temp[i] << endl;
            }
            cout << endl;
            if (getNorma(temp, f.getK()) < eps,size)
            {
                return false;
            }

            if ( 
                getNorma((f.getf(vecX[ind]) - f.getf(vecX[ind-1])) / f.getf(vecX[ind]))< eps, size)
            {
                return false;
            }
        }
        return true;
    }

    void Newton:: calcOptim(vector<double> x, Function& f, Area areaOpt)
    {
        vecX.push_back(x);
        double eps = 0.1;
        int n = f.getK();
        Derivaties* d = new Derivaties(n, eps);
        

        d->calcGradient(f, x);
        d->calcHessian(f, x);

        vector <double> tempP(n, 0), tempX(n,0);
        double alpha = 1;

        for (iter = 0; iter > 500 || Stop( f, d, iter); ++iter, alpha /= 2)
        {
            tempP = calcP(d);
            for (int j = 0; j < n; ++j)
            {
               
                tempX[j] = vecX[iter][j] + tempP[j] * alpha;
                
              //  cout << "x[" << j << "]= " << x[j] << endl;
                //cout << "prev[" << j << "]= " << vecX[iter][j] << endl;
            }
            vecX.push_back(tempX);
            areaOpt.chekArea(vecX,iter,n);
            cout << endl;
            d->calcGradient(f, vecX[iter+1]);
            d->calcHessian(f, vecX[iter+1]);

        }
        invMatr.clear();
    }

    vector<double> Newton::getRez()
    {
        return vecX.back();
    }


   