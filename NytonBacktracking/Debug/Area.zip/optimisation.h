#pragma once
using namespace std;
class Function
{
public:
    virtual int getK() = 0;
    virtual double getf(vector<double> x) = 0;
};

class function2 : public Function
{
public:
    int getK()override;
    double getf(vector<double> x) override;
};

class function3 : public Function
{
public:
    int getK()override;
    double getf(vector<double> x) override;
};




class Derivaties
{
protected:
    double eps = 0.1;
    int n = 0;
    vector<double> gradient;
    vector < vector <double> > hessian;

public:
    Derivaties(int k, double epsN) :n(k),eps(epsN) {};
    vector<vector<double>> getHessian();
    vector<double> getGradient();
    int getN();
    void calcGradient(Function& f, vector<double>& x);
    void calcHessian(Function& f, vector<double>x);

};

void gauseforward(vector<vector<double>>& b, vector<vector<double>>& a, int n, int k);
void gauseback(vector<vector<double>>& b, vector<vector<double>>& a, int n, int k);
void inverse(const vector<vector<double>>& a, vector<vector<double>>& b, int n);


class optimisation
{
    int iter;
    vector<vector<double>> vecX;
    vector<vector<double>> areaOpt;
public:
    int getIter();
    vector<double> getRez();


};



class Newton
{
    double eps = 0.1;
    int iter;
    vector<vector<double>> vecX;
    vector<double> p, temp;
    vector<vector<double>> invMatr;
 
public:
    int getIter();
    double getEps();
    void matByRow(vector<vector<double>>& mat, const vector<double>& vec, vector<double>& p, int n);
    vector<double> calcP(Derivaties* d);

    double getNorma( const vector<double>& x, int n);
    double getNorma(double x);


    bool Stop( Function& f, Derivaties* d, int ind);

    void calcOptim(vector<double> x, Function& f, Area areaOpt);

    vector<double> getRez();
};

